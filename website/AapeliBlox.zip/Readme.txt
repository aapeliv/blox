AapeliBlox v1.0
===============

Copyright (c) 2014 Aapeli Vuorinen.

Free download for Linux and Windows at http://aape.li/blox.



About
=====

A small game where you form rows out of dropping blocks.



Installation
============

To install AapeliBlox, simply extract AapeliBlox.zip into some 
directory and run AapeliBlox.exe from there. If you get errors 
about .dll files, make sure you have extracted the file in a 
folder along with all the appropriate .dll files.



Technical details
=================

AapeliBlox uses the following great libraries/fonts:
SFML, Copyright (c) Laurent Gomila; Inconsolata, Copyright (c) 
2011 Raph Levien (OFL 1.1); Bangers, Copyright (c) 2010 Vernon 
Adams (OFL 1.1); and Chewy (Apache License 2.0).

If you contact me, I might give you the source code.



License
=======

This software is provided 'as-is', without any express or
implied warranty. In no event will the author be held liable
for any damages arising from the use of this software.

This software may be redistributed as permitted by law, given
that this file is included in every distribution.
